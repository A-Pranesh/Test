package com.example.sampleapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public void loginButtonClicked(View view) {
        EditText username = findViewById(R.id.editTextTextPersonName);
        EditText password = findViewById(R.id.editTextTextPassword);
        TextView errorText = findViewById(R.id.textView);
        String usernameString = username.getText().toString();
        String passwordString = password.getText().toString();
        System.out.println("usernmae: " + usernameString);
        System.out.println("passsword: " + passwordString);
        if(usernameString.matches("") || passwordString.matches("")) {
            errorText.setVisibility(View.VISIBLE);
            errorText.setText("Username/Password should not be empty");
        } else {
            errorText.setVisibility(View.GONE);
            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
            intent.putExtra("username", usernameString);
            intent.putExtra("password", passwordString);
            startActivity(intent);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}